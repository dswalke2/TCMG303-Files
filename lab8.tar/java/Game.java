public class Game {
    private Board board;
    boolean finish = false;
    boolean win = false;
    int turn=0;
    
    public Game (){
	    System.out.print("\033[H\033[2J");  
		System.out.flush();
	    System.out.println("\u001B[0m\n\n                 Welcome to Minesweeper!\n             Improved with \u001B[38;5;196m♥\u001B[0m by Colin Keehan\n\n");
        board = new Board();
        Play(board);
    }
    
    public void Play(Board board){
        do{
            turn++;
            if(turn != 1){
	            for (int i=1; i<=29; i++) {
					System.out.print("\033[1A\033[K");
		        }
            }
            //board.resetMines();
            //board.showMines();
            System.out.println("\u001B[38;5;118m                       Attempt "+turn+"\u001B[0m");
            board.show();
            
            
            if(turn == 1){
            	finish = board.firstPosition();
            }
            else {
            	finish = board.setPosition();
            }
            
            
            if(!finish){
                board.openNeighbors();
                finish = board.win();
            }
            
        }while(!finish);
        
        if(board.win()){
	        for (int i=1; i<=30; i++) {
				System.out.print("\033[1A\033[K");
	        }
            System.out.println("\n\u001B[38;5;118m Congratulations!\u001B[0m You located all mines in "+turn+" attempts!\u001B[0m");
            board.showMines();
            System.out.println("\n\n\u001B[38;5;118m                   Thanks for playing!\u001B[0m\n\n");
        } else {
	        for (int i=1; i<=30; i++) {
				System.out.print("\033[1A\033[K");
	        }
            System.out.println("\n\u001B[38;5;196m     Boom!\u001B[0m You've blown up! Better luck next time.\u001B[0m");
            board.showMines();
            System.out.println("\n\n\u001B[38;5;118m                   Thanks for playing!\u001B[0m\n\n");
        }
    }
}
