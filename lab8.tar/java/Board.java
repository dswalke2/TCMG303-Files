import java.util.Random;
import java.util.Scanner;
import java.util.InputMismatchException;

public class Board {
    private int[][] mines;
    private char[][] boardgame;
    private int Line, Column;
    private int didGuess, flagValid, firstPlay;
    private String firstLocation, currentMine;
    Random random = new Random();
    Scanner input = new Scanner(System.in);
    
    public Board (){
        mines = new int[10][10];
        boardgame = new char[10][10];
        startMines();
        //randomMines();
        //fillTips();
        startBoard();
        
    }
    
    public boolean win(){
        int count=0;
        for(int line = 1 ; line < 9 ; line++)
            for(int column = 1 ; column < 9 ; column++)
                if(boardgame[line][column]=='▢' || boardgame[line][column]=='▣' || boardgame[line][column]=='*')
                    count++;
        if(count == 10)
            return true;
        else
            return false;                
    }
    
    public void openNeighbors(){
        for(int i=-1 ; i<2 ; i++)
            for(int j=-1 ; j<2 ; j++)
                if( (mines[Line+i][Column+j] != -1) && (Line != 0 && Line != 9 && Column != 0 && Column != 9) ) {
                    boardgame[Line+i][Column+j]=Character.forDigit(mines[Line+i][Column+j], 10);
					//System.out.println("OPEN NEIGHBORS: " + Character.forDigit(mines[Line+i][Column+j], 10));
				}
    }
    
    public int getPosition(int Line, int Column){
        return mines[Line][Column];
    }
    
    public boolean setPosition(){
            
            do{
                System.out.print("\nGuess (\u001B[38;5;118mg\u001B[0m) or Flag/Unflag (\u001B[38;5;118mf\u001B[0m): \u001B[38;5;118m");
                String action = input.next();
                
                if(action.indexOf("g") >= 0 || action.indexOf("G") >= 0) {
	                flagValid = 0;
	                while (flagValid == 0) {
		                System.out.print("\u001B[0m\nLine: ");
		                boolean ok = false; while(!ok){try{
		                Line = input.nextInt();ok = true;}
		                catch(InputMismatchException e){input.next();
			            System.out.print("\033[1A\033[K\033[1A\033[K\033[1A\033[K\u001B[0mPlease enter a number.\n\nLine: ");}}
		                System.out.print("Column: ");
		                ok = false; while(!ok){try{
		                Column = input.nextInt();ok = true;}
		                catch(InputMismatchException e){input.next();
			            System.out.print("\033[1A\033[K\033[1A\033[K\033[1A\033[K\033[1A\033[K\u001B[0mPlease enter a number.\n\nLine: " + Line + "\nColumn: ");}}
		                
		                if( (boardgame[Line][Column] != '▢') && (boardgame[Line][Column] != '▣') && ((Line < 9 && Line > 0) && (Column < 9 && Column > 0))) {
				            for (int i=1; i<=4; i++) {
								System.out.print("\033[1A\033[K");
					        }
		                    System.out.println("Position already cleared. Try again.");
		                }
		                else{
			                if( Line < 1 || Line > 8 || Column < 1 || Column > 8) {
					            for (int i=1; i<=4; i++) {
									System.out.print("\033[1A\033[K");
						        }
			                    System.out.println("Choose numbers from 1 to 8.");
			                }
			                else {flagValid = 1;}
		                }
	                }
	                didGuess = 1;
                }
                else if(action.indexOf("f") >= 0 || action.indexOf("F") >= 0 || action.indexOf("u") >= 0 || action.indexOf("U") >= 0) {
	                flagValid = 0;
	                while (flagValid == 0) {
		                System.out.print("\u001B[0m\nFlag/Unflag Line: ");
		                boolean ok = false; while(!ok){try{
		                Line = input.nextInt();ok = true;}
		                catch(InputMismatchException e){input.next();
			            System.out.print("\033[1A\033[K\033[1A\033[K\033[1A\033[K\u001B[0mPlease enter a number.\n\nFlag/Unflag Line: ");}}
		                System.out.print("Flag/Unflag Column: ");
		                ok = false; while(!ok){try{
		                Column = input.nextInt();ok = true;}catch(InputMismatchException e){input.next();
			            System.out.print("\033[1A\033[K\033[1A\033[K\033[1A\033[K\033[1A\033[K\u001B[0mPlease enter a number.\n\nFlag/Unflag Line: " 
			            + Line + "\nFlag/Unflag Column: ");}}
		                
		                if( Line < 1 || Line > 8 || Column < 1 || Column > 8) {
				            for (int i=1; i<=4; i++) {
								System.out.print("\033[1A\033[K");
					        }
		                    System.out.println("Choose numbers from 1 to 8.");
		                }
		                else {flagValid = 1;}
	                }
	                if(boardgame[Line][Column] == '▢') {
	                	boardgame[Line][Column] = '▣';
	                }
	                else if (boardgame[Line][Column] == '▣') {
		                boardgame[Line][Column] = '▢';
	                }
	                for (int i=1; i<=28; i++) {
						System.out.print("\033[1A\033[K");
					}
	                show();
		            didGuess = 0;
                }
                else {
	                for (int i=1; i<=2; i++) {
						System.out.print("\033[1A\033[K");
				    }
                }
                
            }while(((Line < 1 || Line > 8 || Column < 1 || Column > 8) || ((boardgame[Line][Column] != '▢') && (boardgame[Line][Column] != '▣') && (boardgame[Line][Column] != '*')) || (didGuess == 0) ));
            
            if(getPosition(Line, Column)== -1) {
	            //System.out.println("Choose a number from 1 to 8.");
                return true;
            }
            else
                return false;
            
    }
    
    
    
    
    public boolean firstPosition(){
            
            do{
                System.out.print("\nGuess (\u001B[38;5;118mg\u001B[0m) or Flag/Unflag (\u001B[38;5;118mf\u001B[0m): \u001B[38;5;118m");
                String action = input.next();
                
                if(action.indexOf("g") >= 0 || action.indexOf("G") >= 0) {
	                System.out.print("\u001B[0m\nLine: ");
	                boolean ok = false; while(!ok){try{
	                Line = input.nextInt();ok = true;}
	                catch(InputMismatchException e){input.next();
		            System.out.print("\033[1A\033[K\033[1A\033[K\033[1A\033[K\u001B[0mPlease enter a number.\n\nLine: ");}}
	                System.out.print("Column: ");
	                ok = false; while(!ok){try{
	                Column = input.nextInt();ok = true;}
	                catch(InputMismatchException e){input.next();
		            System.out.print("\033[1A\033[K\033[1A\033[K\033[1A\033[K\033[1A\033[K\u001B[0mPlease enter a number.\n\nLine: " + Line + "\nColumn: ");}}
	                
	                if( (boardgame[Line][Column] != '▢') && (boardgame[Line][Column] != '▣') && ((Line < 9 && Line > 0) && (Column < 9 && Column > 0))) {
			            for (int i=1; i<=3; i++) {
							//System.out.print("\033[1A\033[K");
				        }
	                    System.out.print("Field already shown. Try again.");
	                }
	                
	                if( Line < 1 || Line > 8 || Column < 1 || Column > 8) {
			            for (int i=1; i<=3; i++) {
							//System.out.print("\033[1A\033[K");
				        }
	                    System.out.println("Choose numbers from 1 to 8.");
	                }
	                didGuess = 1;
                }
                else if(action.indexOf("f") >= 0 || action.indexOf("F") >= 0 || action.indexOf("u") >= 0 || action.indexOf("U") >= 0) {
	                flagValid = 0;
	                while (flagValid == 0) {
		                System.out.print("\u001B[0m\nFlag/Unflag Line: ");
		                boolean ok = false; while(!ok){try{
		                Line = input.nextInt();ok = true;}
		                catch(InputMismatchException e){input.next();
			            System.out.print("\033[1A\033[K\033[1A\033[K\033[1A\033[K\u001B[0mPlease enter a number.\n\nFlag/Unflag Line: ");}}
		                System.out.print("Flag/Unflag Column: ");
		                ok = false; while(!ok){try{
		                Column = input.nextInt();ok = true;}catch(InputMismatchException e){input.next();
			            System.out.print("\033[1A\033[K\033[1A\033[K\033[1A\033[K\033[1A\033[K\u001B[0mPlease enter a number.\n\nFlag/Unflag Line: " 
			            + Line + "\nFlag/Unflag Column: ");}}
		                
		                if( Line < 1 || Line > 8 || Column < 1 || Column > 8) {
				            for (int i=1; i<=4; i++) {
								System.out.print("\033[1A\033[K");
					        }
		                    System.out.println("Choose numbers from 1 to 8.");
		                }
		                else {flagValid = 1;}
	                }
	                if(boardgame[Line][Column] == '▢') {
	                	boardgame[Line][Column] = '▣';
	                }
	                else if (boardgame[Line][Column] == '▣') {
		                boardgame[Line][Column] = '▢';
	                }
	                for (int i=1; i<=28; i++) {
						System.out.print("\033[1A\033[K");
					}
	                show();
		            didGuess = 0;
                }
                else {
	                for (int i=1; i<=2; i++) {
						System.out.print("\033[1A\033[K");
				    }
                }
                
            }while(((Line < 1 || Line > 8 || Column < 1 || Column > 8) || ((boardgame[Line][Column] != '▢') && (boardgame[Line][Column] != '▣') && (boardgame[Line][Column] != '*')) || (didGuess == 0) ));
            
            
			firstLocation = Line + "," + Column;
			firstPlay = 0;
			//System.out.println("First Play Location: " + firstLocation);
			randomMines();
			fillTips();
            
            
	        if(getPosition(Line, Column)== -1) {
                return true;
            }
            else
                return false;
            
            
    }
    
    
    
    
    public void show(){
        System.out.println("\n     Lines");
        for(int Line = 8 ; Line > 0 ; Line--){
            System.out.print("\n       "+Line + " ");
            
            for(int Column = 1 ; Column < 9 ; Column++){
                    //System.out.print("   "+ boardgame[Line][Column]);
                    if(boardgame[Line][Column] == '▣'){
	                    System.out.print("    \u001B[38;5;196m" + '▢' + "\u001B[0m");
                    }
                    else if(boardgame[Line][Column] == '*'){
	                    System.out.print("    \u001B[38;5;196m" + '*' + "\u001B[0m");
                    }
                    else if(boardgame[Line][Column] == '0' || boardgame[Line][Column] == '1' || boardgame[Line][Column] == '2' || boardgame[Line][Column] == '3' || boardgame[Line][Column] == '4' || boardgame[Line][Column] == '5' || boardgame[Line][Column] == '6' || boardgame[Line][Column] == '7' || boardgame[Line][Column] == '8'){
	                    System.out.print("    \u001B[38;5;46m" + boardgame[Line][Column] + "\u001B[0m");
                    }
                    else {
	                    System.out.print("    \u001B[38;5;7m" + boardgame[Line][Column] + "\u001B[0m");//Set background color: \u001B[48;5;0m
                    }
            }
                
            System.out.println();
        }
            
        System.out.println("\n\n             1    2    3    4    5    6    7    8");
        System.out.println("\n                         Columns");
        
    }
    
    public void fillTips(){
        for(int line=1 ; line < 9 ; line++)
            for(int column=1 ; column < 9 ; column++){
                
                    for(int i=-1 ; i<=1 ; i++)
                        for(int j=-1 ; j<=1 ; j++)
                            if(mines[line][column] != -1)
                                if(mines[line+i][column+j] == -1)
                                    mines[line][column]++;
                
            }
            
    }
    
    public void showMines(){
        for(int i=1 ; i < 9; i++)
            for(int j=1 ; j < 9 ; j++)
                if(mines[i][j] == -1)
                    boardgame[i][j]='*';
        
        show();
    }
    
    public void startBoard(){
        for(int i=1 ; i<mines.length ; i++)
            for(int j=1 ; j<mines.length ; j++)
                boardgame[i][j]= '▢';
    }
    
    public void startMines(){
        for(int i=0 ; i<mines.length ; i++)
            for(int j=0 ; j<mines.length ; j++)
                mines[i][j]=0;
    }
    
    public void randomMines(){
        boolean raffled;
        int Line, Column;
        for(int i=0 ; i<10 ; i++){
            do{
	            do {
		            firstPlay = 0;
	                Line = random.nextInt(8) + 1;
	                Column = random.nextInt(8) + 1;
	                currentMine = Line + "," + Column;
					if( firstLocation.equals(currentMine) ) {
					}
					else {
						firstPlay = 1;
					}
                }while(firstPlay==0);
                
                if(mines[Line][Column] == -1) {
                    raffled=true;
				}
                else
                    raffled = false;
            }while(raffled);
            
            mines[Line][Column] = -1;
        }
    }
}

