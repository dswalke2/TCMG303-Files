#!/usr/bin/python3
#This script converts speed from KPH to MPH.
#The conversion formula for kph to mph is :
#1 kilometer = 0.621371192 miles
print (" ")
kph = int(input("Enter KPH: "))
mph = round(0.6214 * kph)
print (" ")
print ("Speed:", kph, "KPH =", mph, "MPH")
print (" ")
print (" ")
if mph > 70:
    print ("Slow down! You were speeding... ")
    print (" ")
else:
    print ("You are a safe driver!")
    print (" ")

