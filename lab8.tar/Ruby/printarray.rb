
# Program to print elements of an array
# Save this as printarray.rb
array1 = ["Ruby", "Perl", "C++", "Java", "Python"]
puts "Unix can be programmed in all these languages: "
puts " "
for array_element in array1
puts array_element
end
TIME = [Time.now]
puts " "
puts "The current time is: "
puts TIME
puts " "
